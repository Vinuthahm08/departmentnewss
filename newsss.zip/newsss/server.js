const express = require('express');
const bodyParser = require('body-parser');
const path = require('path');
const mongoose = require('mongoose');
const router = express.Router();

const app = express();
const port = 4001;

// MongoDB connection URL
const mongoURI = 'mongodb://localhost:27017/mydb'; // Replace with your database name

// Middleware
app.use(bodyParser.urlencoded({ extended: true }));
app.use(bodyParser.json());
app.set('views', path.join(__dirname, 'views'));
app.set('view engine', 'ejs');

// Connect to MongoDB using mongoose
mongoose.connect(mongoURI
)
.then(() => {
    console.log('MongoDB Connected');
    
    // Start server after MongoDB connection is established
    app.listen(port, () => {
        console.log(`Server is running on http://localhost:${port}`);
    });

    // Example route
    app.get('/', (req, res) => {
        res.send('Hello World');
    });

    // Importing routes for all clubs
   const placementRouter=require('./routes/Placement')
    // Use routes for each club
  
    app.use('/place',  placementRouter );
})
.catch(err => console.error('Error connecting to MongoDB:', err));

router.get('/', async (req, res) => {
    try {
        const button = await p.find({});
        res.render('placement', { button });
    } catch (err) {
        console.error('Error fetching notifications:', err);
        res.status(500).send('Internal Server Error');
    }
});