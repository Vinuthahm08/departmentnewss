const express = require('express');
const router = express.Router();
const p = require('../models/placement');

router.get('/', async (req, res) => {
    try {
        const button = await p.find({});
        res.render('placement', { button });
    } catch (err) {
        console.error('Error fetching notifications:', err);
        res.status(500).send('Internal Server Error');
    }
});

module.exports = router;