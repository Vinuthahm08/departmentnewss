const mongoose= require('mongoose');

const placementSchema = new mongoose.Schema({
    no_of_students: Number,
    company_name:String,
    year: Number
},{
    collection:'placement'
});

const place = mongoose.model('placement',placementSchema);

module.export = place;